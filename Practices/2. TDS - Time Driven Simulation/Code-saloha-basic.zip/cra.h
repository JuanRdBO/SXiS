/*
 * Programa exemple del funcionament d'una simulacio orientada a temps
 * per l'assignatura de simulacio de xarxes i sistemes
 * Implementa slotted aloha (model simplificat)
 * 
 * Use: sloha.exe <name-input-file> <name-output-file>
 * Example: sloha.exe ./src/in ./src/out
 
 * Definicions de la llibreria de funcions dels algorismes de resolucio de col.lisions
 * 
 * File:   cra.h
 * Author: Dolors Sala
 *
 * Created on 15 de septiembre de 2014
 *  
 */

#ifndef CRA_H
#define	CRA_H

#include "./saloha.h"

int backoff(int n, char alg);
void compute_optimal_p();

#endif	/* CRA_H */

